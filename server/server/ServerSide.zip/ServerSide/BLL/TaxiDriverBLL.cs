﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataObject;
using DAL;

namespace BLL
{
    public class TaxiDriverBLL
    {
        #region FunctionAdd

        public int Add(TaxiDriverDTO taxiDriver)
        {
            return TaxiDriverDAL.Add(Convert(taxiDriver));
        }

        #endregion

        #region FunctionGetAll

        public List<TaxiDriverDTO> GetAll()
        {
            List<TaxiDriverDTO> listTaxiDriverDTO = new List<TaxiDriverDTO>();
            List<TaxiDriver> listTaxiDriver = TaxiDriverDAL.GetAll();

            foreach (var item in listTaxiDriver)
            {
                listTaxiDriverDTO.Add(Convert(item));
            }
            return listTaxiDriverDTO;
        }

        #endregion

        #region FunctionDelete

        public bool Delete(int taxiDriver)
        {
            return TaxiDriverDAL.Delete(taxiDriver);
        }
       
        #endregion

        #region FunctionConvertDTO

        public TaxiDriverDTO Convert(TaxiDriver newTaxiDriver)
        {
            TaxiDriverDTO taxiDriverDTO = new TaxiDriverDTO();
            taxiDriverDTO.DriverId = newTaxiDriver.DriverId;
            taxiDriverDTO.DriverName = newTaxiDriver.DriverName;
            taxiDriverDTO.PelephoneDriverNumber = newTaxiDriver.PelephoneDriverNumber;
            taxiDriverDTO.VehicleTaxiCode = newTaxiDriver.VehicleTaxiCode;
            taxiDriverDTO.CurrentLocationLat = newTaxiDriver.CurrentLocationLat;
            taxiDriverDTO.CurrentLocationLng = newTaxiDriver.CurrentLocationLng;

            return taxiDriverDTO;
        }

        #endregion

        #region functinConvert

        public TaxiDriver Convert(TaxiDriverDTO newTaxiDriverDTO)
        {
            TaxiDriver taxiDriver = new TaxiDriver();
            taxiDriver.DriverId = newTaxiDriverDTO.DriverId;
            taxiDriver.DriverName = newTaxiDriverDTO.DriverName;
            taxiDriver.PelephoneDriverNumber = newTaxiDriverDTO.PelephoneDriverNumber;
            taxiDriver.VehicleTaxiCode = newTaxiDriverDTO.VehicleTaxiCode;
            taxiDriver.CurrentLocationLat = newTaxiDriverDTO.CurrentLocationLat;
            taxiDriver.CurrentLocationLng = newTaxiDriverDTO.CurrentLocationLng;

            return taxiDriver;
        }

        #endregion

        #region FunctionUpdate

        public bool Update(TaxiDriverDTO upTaxiDriverDTO)
        {
            TaxiDriver taxiDriver = new TaxiDriver();
            taxiDriver = Convert(upTaxiDriverDTO);

            return TaxiDriverDAL.Update(taxiDriver);
        }

        #endregion
    }
}
