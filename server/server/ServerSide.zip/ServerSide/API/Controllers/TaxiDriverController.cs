﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BLL;
using DataObject;

namespace API.Controllers
{
    [RoutePrefix("api/TaxiDriver")]
    public class TaxiDriverController : ApiController
    {
        // GET: api/Taxi
        [Route("GetAll")]
        [HttpGet]

        public List<TaxiDriverDTO> GetAll()
        {
            TaxiDriverBLL taxiDriverBLL = new TaxiDriverBLL();
            return taxiDriverBLL.GetAll();
        }

        // GET: api/Taxi/5
        //[Route("GetById.{id}")]
        //[HttpGet]
        //public List<>GetBYID(int id)
        //{
        //   
        //}

        // POST: api/Taxi
        [Route("{newTaxiDriver}")]
        [HttpPost]

        public int Post(TaxiDriverDTO newTaxiDriver)
        {
            TaxiDriverBLL taxiDriverBLL = new TaxiDriverBLL();
            return taxiDriverBLL.Add(newTaxiDriver);
        }

        // PUT: api/Taxi/5
        [Route("upTaxiDriver")]
        [HttpPut]

        public bool Put(TaxiDriverDTO upTaxiDriver)
        {
            TaxiDriverBLL taxiDriverBLL = new TaxiDriverBLL();

            return taxiDriverBLL.Update(upTaxiDriver);
        }

        // DELETE: api/Taxi/5
        [Route("Delete/{id}")]
        [HttpDelete]

        public bool Delete(int id)
        {
            TaxiDriverBLL taxiDriverBLL = new TaxiDriverBLL();

            return taxiDriverBLL.Delete(id);
        }
    }
}
