﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataObject
{
    public class TaxiDriverDTO
    {
        #region prop

        public int DriverId { get; set; }
        public string DriverName { get; set; }
        public string PelephoneDriverNumber { get; set; }
        public int VehicleTaxiCode { get; set; }
        public double CurrentLocationLat { get; set; }
        public double CurrentLocationLng { get; set; }

        #endregion
    }
}
