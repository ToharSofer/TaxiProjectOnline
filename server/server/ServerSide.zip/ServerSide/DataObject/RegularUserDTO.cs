﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataObject
{
    public class RegularUserDTO
    {
        #region prop

        public int UserId { get; set; }
        public string UserName { get; set; }
        public string CellphoneuserNumber { get; set; }
        public int RecommendedDriverCode { get; set; }

        #endregion
    }
}
